seq = 'h,ffksijq".ki,skdc"js"tki"kij.kb""ck]-dqkl"jqsk-ckui"khjfftkui"k],qsuku,o"ki"kij.kb""cks"cukb"l-c.wkjffkui"k-f.ksu-q,"skij.ky-o"kqdsi,crkbjynwkjc.ki,skb-h"fskij.kudqc".ku-khju"qtki"kij.kfjdri".kjb-duk,ukj]u"qhjq.tki"khjskjk!"u"qjck-]kjkidc.q".kqjcr,crskblkc-hwkjc.kui"k"c.f"ssk.jqnkh,f."qc"sskuijukui"ks-duiq-ckyjff".kui"kijdcu".k]-q"sukij.kc-ko-q"ku"qq-qsk]-qki,otkdcu,fku-c,riutks-o"ui,crkhjsk.,]]"q"cuku-c,riutkui"q"khjskjck".r"ku-kui,sk.jqnc"sskuijukoj."ki,skijynf"skq,s"tkc,c"k.jlskui"lkij.kb""ckq,.,crwkc-quikjc.kc-quih"sukjc.kui"ckc-quikjrj,cwk]jqui"qkjc.k]jqui"qk]q-okui"khjffwkijq.k-ckui"kuqjynk-]kjkbjc.k-]kh,f.f,crkqj,."qstk"jyik.jlkij.kb""ckh-qs"kuijckui"k.jlkuijukij.ky-o"kb"]-q"k,utku-.jlkhjskui"kh-qsuk-]kjfftkjky-f.kh,c.khjskbf-h,crk-duk-]kui"kc-quiwkjc.k,ukoj."kui"kuq""skqdsuf"kf,n"kf,!,crkui,crstkjffk.jlwkh,ffkij.k]"fukjskui-driks-o"ui,crkh"q"khjuyi,crki,owks-o"ui,crky-f.kjc.k,o''fjyjbf"kuijukf-!".ki,okc-utkrjq".kij.k]"fuk,uku--tkh,ffkhjcu".kc-ui,crks-kodyikjsku-kq,."ki"ffb"cuk]-qkui"ksj]"ulk-]kui"khjffwkbdukuijukhjskc-ukjk]""f,crku-ksijq"kh,uikl-dqky-oojc."qtk"s''"y,jfflkc-ukjky-oojc."qkf,n"kui,sk-c"t';
alphabet = 'abcdefghijklmnopqrstuvwxyz,.''"-!?:;()[] ';
N = length(alphabet);
load('pinit.mat');
load('Q.mat');

% file = fopen('seq.txt');
% seq_alt = textscan(file, '%s');
% fclose(file);
% 
% seq_alt = seq_alt{1}
% 
% strcmp(seq, seq_alt{1})