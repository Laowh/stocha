% Retrouve le texte original dans la plupart des cas (ou proche).
% Avec ce nombre d'it�rations l'execution peut prendre
% 150 - 250 secondes
% Parfois le programme se trompe assez fortement et reste bloqu� avec un mauvais code 

seq2;
vraisemb = -Inf;

%code al�atoire
permutation = alphabet(randperm(40));
sim = [0];
%nombre d'it�rations
it = 0;

prev_it = 0;
%Donn�es pour le graph
Tab_vraisemblance_alt = [vraisemb];
permutation = alphabet(randperm(40));
nb_unique = length(unique(seq));

%Fait des permutations al�atoires dans le code et si meilleure vraisemblance on garde
while(sim(end) < 0.8* nb_unique)
   permutation_next = exchange (permutation, randi(40), randi(40)) ;
   %translation_next = transmute (seq, permutation_next, alphabet);
   vraisemb_next = vraisemblance_alt(seq,permutation_next,pinit,Q);

   if(randi(1) < (2^(vraisemb_next - vraisemb)))
     %On garde le nouveau code
     permutation = permutation_next;
     vraisemb = vraisemb_next;
     translation = transmute (seq, permutation_next, alphabet);
     
     %donn�es graphiques
     Tab_vraisemblance_alt = [Tab_vraisemblance_alt vraisemb];
     sim = [sim common(true_permutation, permutation)];
     prev_it = it;
   end 
   it = it+1;
   %empeche de tourner ind�finiment
   if (it > prev_it + 100000)
       disp("no improvement after 100 000 iterations. Program stops");
       break;
   end
end
figure(1);
plot(Tab_vraisemblance_alt);
title('Vraisemblance � chaque permutation effectu�e')
ylabel('Vraisemblance');
xlabel('Nombre de permutations');
figure(2);
plot(sim);
title('Substitutions correctes � chaque permutation effectu�e')
ylabel('Nombre de substitutions correctes');
xlabel('Nombre de permutations');

permutation
translation
vraisemb
