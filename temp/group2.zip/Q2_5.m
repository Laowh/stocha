% Retrouve le texte original dans la plupart des cas (ou proche).
% Avec ce nombre d'it�rations l'execution peut prendre
% 150 - 250 secondes

seq2;

tic;

p = 1/factorial(40);
vraisemb = -Inf;

%code al�atoire
permutation = alphabet(randperm(40));

%Nombre d'it�rations

it = 150000;
%Donn�es pour le graph
Tab_vraisemblance_alt = [vraisemb];

%Fait des permutations al�atoires dans le code et si meilleure vraisemblance on garde
while(it > 0)
   permutation_next = exchange (permutation, randi(40), randi(40)) ;
   %translation_next = transmute (seq, permutation_next, alphabet);
   vraisemb_next = vraisemblance_alt(seq,permutation_next,pinit,Q);
    
   if(randi(1) < (2^(vraisemb_next - vraisemb)))
     permutation = permutation_next;
     vraisemb = vraisemb_next;
     translation = transmute (seq, permutation_next, alphabet);
     Tab_vraisemblance_alt = [Tab_vraisemblance_alt vraisemb];
   end 
   it = it-1;
end
plot(Tab_vraisemblance_alt);

permutation
translation
vraisemb
toc;
